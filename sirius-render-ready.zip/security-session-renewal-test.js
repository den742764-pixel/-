'use strict';
// Integration regression: valid activity renews the rolling one-year session window.
const {spawn}=require('child_process');
const fs=require('fs'),os=require('os'),path=require('path'),net=require('net'),assert=require('assert/strict'),crypto=require('crypto');
const ecdh=crypto.createECDH('prime256v1');ecdh.generateKeys();const pub=ecdh.getPublicKey();
const validPk=JSON.stringify({kty:'EC',crv:'P-256',x:pub.subarray(1,33).toString('base64url'),y:pub.subarray(33,65).toString('base64url'),ext:true,key_ops:[]});
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
async function start(port,data){const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,TRUST_PROXY:'0',DEV_CODE:'test-only-secret-that-is-longer-than-32-chars'},stdio:['ignore','ignore','pipe']});let logs='';child.stderr.on('data',d=>logs+=d.toString());const base=`http://127.0.0.1:${port}/api/`;let ready=false;for(let i=0;i<80;i++){try{if((await fetch(base+'ping')).ok){ready=true;break}}catch{}await wait(100)}assert(ready,'server did not start: '+logs);return{child,base,logs:()=>logs}}
async function stop(child){child.kill('SIGTERM');await Promise.race([new Promise(r=>child.once('exit',r)),wait(1500)])}
async function post(base,route,body){const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return{status:r.status,body:await r.json()}}
async function main(){const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-renew-'));let child;
try{let srv=await start(port,data);child=srv.child;const token=crypto.randomBytes(32).toString('hex');
const reg=await post(srv.base,'auth/register',{token,name:'RenewTest',un:'renew_test',pk:validPk,seen:Date.now(),salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});assert.equal(reg.status,200,'registration failed');const uid=reg.body.uid;
await wait(800);await stop(child);child=null;
const dbPath=path.join(data,'db.json'),db=JSON.parse(fs.readFileSync(dbPath,'utf8')),old=Date.now()-6*60*1000;db.tokenMeta[uid].last=old;db.tokenMeta[uid].exp=old+30*24*60*60*1000;fs.writeFileSync(dbPath,JSON.stringify(db),{mode:0o600});
srv=await start(port,data);child=srv.child;const r=await post(srv.base,'w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{bio:'rolling expiry'}});assert.equal(r.status,200,'valid older session rejected');await wait(800);await stop(child);child=null;
const updated=JSON.parse(fs.readFileSync(dbPath,'utf8')).tokenMeta[uid];assert(updated.last>Date.now()-60*1000,'last activity was not refreshed');assert(updated.exp>Date.now()+364*24*60*60*1000,'session expiration was not extended to one year from activity');
console.log('PASS: active session renews its one-year inactivity window across server restart');
}finally{if(child)await stop(child);fs.rmSync(data,{recursive:true,force:true})}}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});

'use strict';
// TCP-level connection cap prevents one peer from exhausting sockets with slow/incomplete HTTP headers.
const {spawn}=require('child_process');
const fs=require('fs'),os=require('os'),path=require('path'),net=require('net'),assert=require('assert/strict');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
function connect(port){return new Promise((resolve,reject)=>{const s=net.createConnection({host:'127.0.0.1',port});s.once('connect',()=>resolve(s));s.once('error',reject)})}
async function main(){
 const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-tcp-limit-'));
 const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,TRUST_PROXY:'0',MAX_TCP_CONNECTIONS_PER_IP:'20',DEV_CODE:'tcp-limit-regression-secret-9c2f7b4e6a1d8c3f'},stdio:['ignore','ignore','pipe']});
 let logs='';child.stderr.on('data',d=>logs+=d.toString());const sockets=[];
 try{
  let ready=false;for(let i=0;i<80;i++){try{if((await fetch(`http://127.0.0.1:${port}/api/ping`)).ok){ready=true;break}}catch{}await wait(100)}assert(ready,'server did not start: '+logs);
  // Close the health-check keep-alive socket before counting raw connections.
  for(let i=0;i<20;i++){const s=await connect(port);sockets.push(s)}
  const excess=await connect(port).catch(()=>null);if(excess)sockets.push(excess);await wait(200);
  assert(!excess||excess.destroyed,'peer connection above configured cap was not closed');
  sockets[0].destroy();await wait(150);
  const replacement=await connect(port);sockets.push(replacement);await wait(100);
  assert(!replacement.destroyed,'TCP slot was not released after disconnect');
  console.log('PASS: TCP sockets are capped per peer and capacity is released after disconnect');
 }finally{for(const s of sockets)try{s.destroy()}catch{}child.kill('SIGTERM');await Promise.race([new Promise(r=>child.once('exit',r)),wait(1500)]);fs.rmSync(data,{recursive:true,force:true})}
}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});

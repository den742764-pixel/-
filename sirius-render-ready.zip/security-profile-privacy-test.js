'use strict';
// Regression test for profile privacy: phone numbers are friend-only and invisible users hide last-seen.
const {spawn}=require('child_process');
const fs=require('fs');const os=require('os');const path=require('path');const net=require('net');const crypto=require('crypto');const assert=require('assert/strict');
const hash=x=>crypto.createHash('sha256').update(String(x)).digest('hex');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
async function main(){
  const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-privacy-'));
  const now=Date.now(),ownerToken='owner-token-0123456789abcdef0123456789abcdef',friendToken='friend-token-0123456789abcdef0123456789abcdef',strangerToken='stranger-token-0123456789abcdef0123456789abcdef';
  const users={
    '11111111':{name:'Owner',un:'privacy_owner',ph:'491234567890',fph:true,invisible:true,seen:now-1000,pk:''},
    '22222222':{name:'Friend',un:'privacy_friend',invisible:false,seen:now,pk:''},
    '33333333':{name:'Stranger',un:'privacy_stranger',invisible:false,seen:now,pk:''}
  };
  const db={audit:[],ordn:0,secret:'privacy-test-secret',mq:{},mediaOwner:{},tokens:{'11111111':hash(ownerToken),'22222222':hash(friendToken),'33333333':hash(strangerToken)},tokenMeta:{},rec:{},bal:{},orders:{},admins:{},gcount:{},users,friends:{'11111111_22222222':{from:'11111111',to:'22222222',st:'ok'}},blocks:{},posts:{},groups:{},stories:{},calls:{},msgs:{},gifts:{}};
  for(const [uid,tok] of [['11111111',ownerToken],['22222222',friendToken],['33333333',strangerToken]])db.tokenMeta[uid]={created:now,last:now,exp:now+365*24*60*60*1000};
  fs.writeFileSync(path.join(data,'db.json'),JSON.stringify(db),{mode:0o600});
  const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,TRUST_PROXY:'0',DEV_CODE:'test-only-secret-that-is-longer-than-32-chars'},stdio:['ignore','ignore','pipe']});
  let logs='';child.stderr.on('data',d=>logs+=d.toString());const base=`http://127.0.0.1:${port}/api/`;
  async function post(route,body){const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return{status:r.status,body:await r.json()}}
  async function profileFor(uid,tok){const t=await post('session/streamticket',{u:uid,t:tok});assert.equal(t.status,200,'stream ticket unavailable');const r=await fetch(base+'stream?ticket='+encodeURIComponent(t.body.ticket));assert.equal(r.status,200);const reader=r.body.getReader();const first=await reader.read();await reader.cancel();const line=new TextDecoder().decode(first.value).split('\n').find(x=>x.startsWith('data: '));assert(line,'missing initial stream state');return JSON.parse(line.slice(6)).s.users['11111111']}
  try{
    let ready=false;for(let i=0;i<60;i++){try{const r=await fetch(base+'ping');if(r.ok){ready=true;break}}catch{}await wait(100)}assert(ready,'server failed to start: '+logs);
    const stranger=await profileFor('33333333',strangerToken);assert.equal(stranger.ph,undefined,'phone number leaked to a non-friend');assert.equal(stranger.seen,undefined,'invisible profile leaked last-seen timestamp');
    const friend=await profileFor('22222222',friendToken);assert.equal(friend.ph,'491234567890','phone number was not available to an accepted friend');assert.equal(friend.seen,undefined,'invisible profile leaked last-seen timestamp to a friend');
    const owner=await profileFor('11111111',ownerToken);assert.equal(owner.ph,'491234567890','owner cannot see their own phone');assert.equal(owner.seen,now-1000,'owner cannot see own last-seen');
    console.log('PASS: phone number is visible only to accepted friends when fph is enabled');
    console.log('PASS: invisible profiles hide last-seen timestamps from other users');
  }finally{child.kill('SIGTERM');await Promise.race([new Promise(r=>child.once('exit',r)),wait(1500)]);fs.rmSync(data,{recursive:true,force:true})}
}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});

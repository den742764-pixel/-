'use strict';
// End-to-end test: owner configures transfer details, user creates/claims an order,
// owner confirms once, and replay cannot credit the balance twice.
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const net=require('node:net');
const {spawn}=require('node:child_process');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
async function main(){
 const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-paycfg-'));
 const secret='payment-test-secret-that-is-longer-than-32-chars';
 const token=crypto.randomBytes(32).toString('hex');
 const ecdh=crypto.createECDH('prime256v1');ecdh.generateKeys();const pub=ecdh.getPublicKey();
 const pk=JSON.stringify({kty:'EC',crv:'P-256',x:pub.subarray(1,33).toString('base64url'),y:pub.subarray(33,65).toString('base64url'),ext:true,key_ops:[]});
 const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,DEV_CODE:secret,NODE_ENV:'test',REQUIRE_HTTPS:'0',REDIS_URL:'',OWNER_CARD:'',OWNER_NAME:'',OWNER_BANK:'',PAY_URL:''},stdio:['ignore','pipe','pipe']});
 let logs='';child.stdout.on('data',d=>logs+=d.toString());child.stderr.on('data',d=>logs+=d.toString());
 const base=`http://127.0.0.1:${port}/api/`;
 async function post(route,body){const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return{status:r.status,body:await r.json()}}
 try{
  let ready=false;for(let i=0;i<80;i++){if(child.exitCode!==null)throw Error('server exited: '+logs);try{const r=await fetch(base+'ping',{signal:AbortSignal.timeout(500)});if(r.ok){ready=true;break}}catch{}await wait(100)}assert(ready,'server did not start: '+logs);
  let r=await post('auth/register',{token,name:'Payment Owner',un:'payment_owner',pk,seen:Date.now(),salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsb25hc2R1dnd4eXo='});assert.equal(r.status,200,'owner registration failed: '+JSON.stringify(r.body));const u=r.body.uid;
  r=await post('dev/redeem',{u,t:token,code:secret,amt:0});assert.equal(r.status,200,'owner activation failed');
  r=await post('admin/paycfg',{u,t:token,card:'1234 5678 9012 3456',holder:'Test Receiver',bank:'Test Bank',url:'https://example.com/pay'});assert.equal(r.status,200,'payment settings were not saved');
  r=await post('shop/state',{u,t:token});assert.equal(r.status,200);assert.equal(r.body.cfg.card,'1234567890123456');assert.equal(r.body.cfg.holder,'Test Receiver');assert.equal(r.body.cfg.bank,'Test Bank');assert.equal(r.body.cfg.ready,true);
  let invalid=await post('admin/paycfg',{u,t:token,card:'1234567890',holder:'Test',bank:'Bank',url:'javascript:alert(1)'});assert.equal(invalid.status,400,'non-HTTPS payment URL was accepted');
  r=await post('shop/order',{u,t:token,amt:25});assert.equal(r.status,200,'order creation failed');const order=r.body.order;assert.equal(order.rub,25);
  r=await post('shop/paid',{u,t:token,id:order.id,note:'paid'});assert.equal(r.status,200,'buyer could not mark order paid');
  r=await post('admin/confirm',{u,t:token,id:order.id});assert.equal(r.status,200,'owner could not confirm order');
  r=await post('shop/state',{u,t:token});assert.equal(r.body.bal,75,'welcome bonus plus paid stars were not credited exactly once');
  r=await post('admin/confirm',{u,t:token,id:order.id});assert.notEqual(r.status,200,'duplicate confirmation was accepted');
  r=await post('shop/state',{u,t:token});assert.equal(r.body.bal,75,'duplicate confirmation credited stars twice');
  console.log('PASS: owner can save payment details; buyer sees them; invalid URLs rejected; manual payment confirmation credits once only');
 }finally{child.kill('SIGTERM');await Promise.race([new Promise(resolve=>child.once('exit',resolve)),wait(2000)]);if(child.exitCode===null)child.kill('SIGKILL');fs.rmSync(data,{recursive:true,force:true})}
}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});

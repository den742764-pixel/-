'use strict';
// Integration regression: many accounts from one IP cannot consume unlimited SSE sockets.
const {spawn}=require('child_process');
const fs=require('fs'),os=require('os'),path=require('path'),net=require('net'),assert=require('assert/strict'),crypto=require('crypto');
const ecdh=crypto.createECDH('prime256v1');ecdh.generateKeys();const pub=ecdh.getPublicKey();
const validPk=JSON.stringify({kty:'EC',crv:'P-256',x:pub.subarray(1,33).toString('base64url'),y:pub.subarray(33,65).toString('base64url'),ext:true,key_ops:[]});
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
async function main(){
 const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-sse-ip-'));
 const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,TRUST_PROXY:'0',DEV_CODE:'sse-ip-limit-regression-secret-7f3d9c2a6b8e4f1d'},stdio:['ignore','ignore','pipe']});
 let logs='';child.stderr.on('data',d=>logs+=d.toString());const base=`http://127.0.0.1:${port}/api/`,controllers=[];
 async function post(route,body){const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return{status:r.status,body:await r.json()}}
 try{
  let ready=false;for(let i=0;i<80;i++){try{if((await fetch(base+'ping')).ok){ready=true;break}}catch{}await wait(100)}assert(ready,'server did not start: '+logs);
  const accounts=[];
  for(let i=0;i<6;i++){
   const token=crypto.randomBytes(32).toString('hex');
   const r=await post('auth/register',{token,name:'StreamTest'+i,un:'stream_test_'+i,pk:validPk,seen:Date.now(),salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});
   assert.equal(r.status,200,'registration failed: '+JSON.stringify(r.body));accounts.push({u:r.body.uid,t:token});
  }
  let opened=0,blocked=false;
  for(let i=0;i<31;i++){
   const a=accounts[Math.floor(i/6)];
   const t=await post('session/streamticket',{u:a.u,t:a.t});assert.equal(t.status,200,'ticket failed at '+i+': '+JSON.stringify(t.body));
   const controller=new AbortController();controllers.push(controller);
   const response=await fetch(base+'stream?ticket='+encodeURIComponent(t.body.ticket),{signal:controller.signal});
   if(i<30){assert.equal(response.status,200,'SSE connection unexpectedly rejected at '+i);opened++}
   else {assert.equal(response.status,429,'31st connection from same IP was not blocked');blocked=true;controller.abort()}
  }
  assert.equal(opened,30);assert(blocked);
  // Closing a stream must release both counters; otherwise transient disconnects
  // could permanently consume the per-IP quota until the process restarts.
  controllers[0].abort();await wait(250);
  const retryTicket=await post('session/streamticket',{u:accounts[0].u,t:accounts[0].t});assert.equal(retryTicket.status,200);
  const retryController=new AbortController();controllers.push(retryController);
  const retry=await fetch(base+'stream?ticket='+encodeURIComponent(retryTicket.body.ticket),{signal:retryController.signal});
  assert.equal(retry.status,200,'closing a stream did not release the per-IP connection slot');
  console.log('PASS: SSE per-IP/account limits use counters, block excess streams, and release capacity on disconnect');
 }finally{for(const c of controllers)try{c.abort()}catch{}child.kill('SIGTERM');await Promise.race([new Promise(r=>child.once('exit',r)),wait(1500)]);fs.rmSync(data,{recursive:true,force:true})}
}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});

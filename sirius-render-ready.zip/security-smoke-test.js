'use strict';
// Repeatable regression checks for account/session security. Run: npm test
const {spawn}=require('child_process');
const fs=require('fs');
const os=require('os');
const path=require('path');
const net=require('net');
const assert=require('assert/strict');
const nodeCrypto=require('crypto');
const ecdh=nodeCrypto.createECDH('prime256v1');ecdh.generateKeys();const pub=ecdh.getPublicKey();const validPk=JSON.stringify({kty:'EC',crv:'P-256',x:pub.subarray(1,33).toString('base64url'),y:pub.subarray(33,65).toString('base64url'),ext:true,key_ops:[]});
const b64=b=>Buffer.from(b).toString('base64');
const fakeE2EBody=()=>b64(Buffer.from(JSON.stringify({v:2,s:b64(nodeCrypto.randomBytes(16)),i:b64(nodeCrypto.randomBytes(12)),c:b64(nodeCrypto.randomBytes(32))})));

function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function main(){
  const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-sec-'));
  const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,TRUST_PROXY:'0',DEV_CODE:'test-only-secret-that-is-longer-than-32-chars'},stdio:['ignore','ignore','pipe']});
  let logs='';child.stderr.on('data',d=>logs+=d.toString());
  const base=`http://127.0.0.1:${port}/api/`;
  async function post(route,body){const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return {status:r.status,body:await r.json()}}
  try{
    let ready=false;
    for(let i=0;i<60;i++){try{const r=await fetch(base+'ping');if(r.ok){ready=true;break}}catch{}await wait(100)}
    assert(ready,'server did not start: '+logs);
    const headerProbe=await fetch(base+'ping');assert.equal(headerProbe.headers.get('x-content-type-options'),'nosniff','baseline security headers missing on success response');
    const longTarget=await fetch(base+'ping?x='+('a'.repeat(4200)));assert.equal(longTarget.status,414,'oversized request target was not rejected');assert.equal(longTarget.headers.get('x-content-type-options'),'nosniff','early error response omitted security headers');
    const token='a'.repeat(32);
    // Public identity keys must be real P-256 public JWKs, never arbitrary strings or private JWKs.
    let r=await post('auth/register',{token,name:'BadKey',un:'bad_key_test',pk:'not-a-public-key',salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});
    assert.equal(r.status,400,'invalid public key accepted');
    // API JSON endpoints reject form/text content types.
    const ct=await fetch(base+'w',{method:'POST',headers:{'content-type':'text/plain'},body:'{}'});assert.equal(ct.status,415,'non-JSON API request accepted');
    // Oversized request bodies are rejected with HTTP 413 without resetting the connection before the response.
    const oversized=await fetch(base+'auth/register',{method:'POST',headers:{'content-type':'application/json'},body:' '.repeat(600001)});assert.equal(oversized.status,413,'oversized request body was not cleanly rejected');
    // Browser-origin checks reject cross-site state-changing requests, while same-origin remains usable.
    const hostile=await fetch(base+'auth/register',{method:'POST',headers:{'content-type':'application/json','origin':'https://attacker.example'},body:JSON.stringify({token:'z'.repeat(32)})});
    assert.equal(hostile.status,403,'cross-origin POST was not blocked');
    const sameOrigin=await fetch(base+'auth/register',{method:'POST',headers:{'content-type':'application/json','origin':`http://127.0.0.1:${port}`},body:JSON.stringify({token:'z'.repeat(32),name:'BadKey',un:'bad_key_test',pk:'invalid',salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='})});
    assert.equal(sameOrigin.status,400,'same-origin API request was blocked before validation');
    // A random unknown ID must not be claimable through normal authenticated APIs.
    r=await post('w',{u:'12345678',t:token,op:'set',c:'users',id:'12345678',v:{name:'victim',un:'victim_1'}});
    assert.equal(r.status,401,'unknown account was bootstrapped by normal API');
    r=await post('auth/register',{token,name:'SecurityTest',un:'security_test',pk:validPk,seen:Date.now(),salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});
    assert.equal(r.status,200,'registration failed');assert.match(r.body.uid,/^\d{8}$/,'server did not assign numeric UID');
    const uid=r.body.uid;
    // Recovery-start must not reveal whether a username exists by UID format or salt shape.
    const malformedRecovery=await post('rec/do',{uid:'x'.repeat(100000),tok:'x',proof:'x'});assert.equal(malformedRecovery.status,403,'oversized malformed recovery UID was not safely rejected');
    const recoveryKnown=await post('rec/start',{un:'security_test'});
    const recoveryUnknown=await post('rec/start',{un:'not_a_real_account'});
    assert.equal(recoveryKnown.status,200);assert.equal(recoveryUnknown.status,200);
    for(const x of [recoveryKnown.body,recoveryUnknown.body]){
      assert.match(x.uid,/^\d{8}$/,'recovery start leaks account existence via UID format');
      assert.match(x.salt,/^[A-Za-z0-9+/]{20,24}={0,2}$/,'recovery start returned distinguishable salt format');
    }
    assert.notEqual(recoveryKnown.body.uid,recoveryUnknown.body.uid,'test identities unexpectedly collided');
    r=await post('w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{bio:'test'}});assert.equal(r.status,200,'valid token rejected');
    r=await post('w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{role:'admin'}});assert.equal(r.status,403,'client could write an arbitrary privilege field to its profile');
    r=await post('w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{hidden:true}});assert.equal(r.status,403,'client could modify server-managed hidden flag');
    r=await post('w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{ph:'9999999999'}});assert.equal(r.status,403,'client could directly overwrite a server-managed phone field');
    r=await post('w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{invisible:'false'}});assert.equal(r.status,403,'non-boolean privacy control was accepted');
    r=await post('w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{av:'data:image/png;base64,aGVsbG8='}});assert.equal(r.status,403,'profile accepted a mislabeled non-image data URL');
    r=await post('w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{av:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/XioAAAAASUVORK5CYII='}});assert.equal(r.status,200,'profile rejected a supported image with a valid PNG signature');
    r=await post('auth/register',{token:'b'.repeat(32),name:'Other',un:'security_test',pk:validPk,salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'b'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});assert.equal(r.status,409,'duplicate username accepted');
    r=await post('session/streamticket',{u:uid,t:token});assert.equal(r.status,200,'stream ticket issuance failed');assert.match(r.body.ticket,/^[a-f0-9]{64}$/);
    const stream=await fetch(base+'stream?ticket='+encodeURIComponent(r.body.ticket));assert.equal(stream.status,200,'one-time stream ticket rejected');await stream.body.cancel();
    const replay=await fetch(base+'stream?ticket='+encodeURIComponent(r.body.ticket));assert.equal(replay.status,401,'stream ticket could be replayed');
    // Cross-account authorization: Bob cannot spoof Alice's message or alter its ciphertext.
    const tokenB='d'.repeat(32), tokenC='e'.repeat(32);
    let rb=await post('auth/register',{token:tokenB,name:'Second',un:'security_second',pk:validPk,salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'d'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});
    assert.equal(rb.status,200,'second account registration failed'); const uidB=rb.body.uid;
    let rc=await post('auth/register',{token:tokenC,name:'Third',un:'security_third',pk:validPk,salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'e'.repeat(64),vault:'YWJjZGVmZ2hpamtsb25hc2R1dnd4eXo='});
    assert.equal(rc.status,200,'third account registration failed'); const uidC=rc.body.uid;
    // The server, not just the client UI, must enforce friends-only and block settings for new DMs.
    const conv=[uid,uidB].sort().join('_');
    r=await post('w',{u:uidB,t:tokenB,op:'update',c:'users',id:uidB,v:{fonly:true}});assert.equal(r.status,200,'could not enable friends-only messages');
    r=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'friends_only_bypass',v:{c:conv,from:uid,t:Date.now(),kind:'e2e',body:fakeE2EBody(),e:2,rx:{},rd:0}});assert.equal(r.status,403,'friends-only message policy was bypassed through the API');
    r=await post('w',{u:uidB,t:tokenB,op:'update',c:'users',id:uidB,v:{fonly:false}});assert.equal(r.status,200,'could not disable friends-only messages');
    r=await post('w',{u:uidB,t:tokenB,op:'set',c:'blocks',id:uidB+'_'+uid,v:{by:uidB,to:uid}});assert.equal(r.status,200,'could not create block for regression test');
    r=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'block_bypass',v:{c:conv,from:uid,t:Date.now(),kind:'e2e',body:fakeE2EBody(),e:2,rx:{},rd:0}});assert.equal(r.status,403,'blocked user sent a new direct message through the API');
    // A recipient-side block must also stop the gift endpoint before balance checks.
    r=await post('w',{u:uidB,t:tokenB,op:'set',c:'blocks',id:uidB+'_'+uid,v:{by:uidB,to:uid}});assert.equal(r.status,200,'could not create recipient-side block for gift test');
    r=await post('gift/send',{u:uid,t:token,to:uidB,gid:'rose'});assert.equal(r.status,403,'gift endpoint bypassed a block created by the recipient');
    r=await post('w',{u:uidB,t:tokenB,op:'delete',c:'blocks',id:uidB+'_'+uid});assert.equal(r.status,200,'could not remove recipient-side block after gift test');
    // Gift endpoint has a per-account burst limit, independent of the global IP limit.
    const giftBurst=[];for(let i=0;i<21;i++)giftBurst.push(await post('gift/send',{u:uidC,t:tokenC,to:uidB,gid:'rose'}));
    assert(giftBurst.some(x=>x.status===429),'gift endpoint has no per-account rate limit: '+giftBurst.map(x=>x.status).join(','));
    r=await post('w',{u:uidB,t:tokenB,op:'delete',c:'blocks',id:uidB+'_'+uid});assert.equal(r.status,200,'could not remove block after regression test');
    r=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'multi_party_bypass',v:{c:[uid,uidB,uidC].sort().join('_'),from:uid,t:Date.now(),kind:'e2e',body:fakeE2EBody(),e:2,rx:{},rd:0}});assert.equal(r.status,403,'forged multi-party direct-message ID was accepted');
    // A forged e=2 marker must not let a client inject plaintext into a DM.
    r=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'plaintext_dm_bypass',v:{c:conv,from:uid,t:Date.now(),kind:'text',body:'plaintext must be rejected',e:2,rx:{},rd:0}});assert.equal(r.status,403,'plaintext direct message was accepted with a forged encryption flag');
    r=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'extra_fields_bypass',v:{c:conv,from:uid,t:Date.now(),kind:'e2e',body:fakeE2EBody(),e:2,rx:{},rd:0,admin:true}});assert.equal(r.status,400,'unknown server-controlled message field was accepted');
    r=await post('w',{u:uid,t:token,op:'set',c:'groups',id:conv,v:{by:uid,mem:[uid,uidB],adm:[uid],ch:0}});assert.equal(r.status,400,'group ID collided with a direct conversation ID');
    // A member removed from a group must not retain write access to their old group messages.
    const groupId='security_group_test',groupMsg='removed_member_msg';
    r=await post('w',{u:uid,t:token,op:'set',c:'groups',id:groupId,v:{by:uid,un:'security_group_test',mem:[uid,uidB],adm:[uid],ch:0}});assert.equal(r.status,200,'group setup failed');
    r=await post('w',{u:uid,t:token,op:'update',c:'groups',id:groupId,v:{mem:[uid],adm:[uidC]}});assert.equal(r.status,403,'group admin list accepted a non-member or excluded owner');
    r=await post('w',{u:uid,t:token,op:'update',c:'groups',id:groupId,v:{mem:[uid,uidB,uidB],adm:[uid]}});assert.equal(r.status,403,'duplicate group membership was accepted');
    r=await post('w',{u:uidB,t:tokenB,op:'set',c:'msgs',id:groupMsg,v:{c:groupId,from:uidB,t:Date.now(),kind:'text',body:'before removal',rx:{},rd:0}});assert.equal(r.status,200,'group member could not post');
    r=await post('w',{u:uid,t:token,op:'update',c:'groups',id:groupId,v:{mem:[uid],adm:[uid]}});assert.equal(r.status,200,'group member removal failed');
    r=await post('w',{u:uidB,t:tokenB,op:'update',c:'msgs',id:groupMsg,v:{body:'edited after removal'}});assert.equal(r.status,403,'removed group member retained message write access');
    const malformedEnvelope=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'malformed_e2e_envelope',v:{c:conv,from:uid,t:Date.now(),kind:'e2e',body:'not-an-envelope',e:2,rx:{},rd:0}});
    assert.equal(malformedEnvelope.status,400,'malformed E2E envelope was accepted');
    const msgId='cross_account_message_1';
    r=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:msgId,v:{c:conv,from:uid,t:Date.now(),kind:'e2e',body:fakeE2EBody(),e:2,rx:{},rd:0}});
    assert.equal(r.status,200,'Alice could not create her own encrypted message');
    r=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'future_message_test',v:{c:conv,from:uid,t:Date.now()+86400000,kind:'e2e',body:fakeE2EBody(),e:2,rx:{},rd:0}});
    assert.equal(r.status,400,'message with a far-future timestamp was accepted');
    const hugeRx=Object.fromEntries(Array.from({length:501},(_,i)=>['user'+i,[uid]]));
    r=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'oversized_receipts_test',v:{c:conv,from:uid,t:Date.now(),kind:'e2e',body:fakeE2EBody(),e:2,rx:hugeRx,rd:0}});
    assert.equal(r.status,400,'message with oversized receipt metadata was accepted');
    r=await post('w',{u:uidB,t:tokenB,op:'update',c:'msgs',id:msgId,v:{body:fakeE2EBody()}});
    assert.equal(r.status,403,'recipient modified sender ciphertext');
    r=await post('w',{u:uidB,t:tokenB,op:'set',c:'msgs',id:'spoofed_message_1',v:{c:conv,from:uid,t:Date.now(),kind:'e2e',body:fakeE2EBody(),e:2,rx:{},rd:0}});
    assert.equal(r.status,403,'Bob spoofed a message as Alice');
    r=await post('session/streamticket',{u:uidC,t:tokenC});assert.equal(r.status,200,'third-account stream ticket failed');
    const outsiderStream=await fetch(base+'stream?ticket='+encodeURIComponent(r.body.ticket));assert.equal(outsiderStream.status,200,'third-account stream failed');
    const reader=outsiderStream.body.getReader();const first=await reader.read();await reader.cancel();
    const initText=new TextDecoder().decode(first.value||new Uint8Array());
    assert(!initText.includes(msgId),'unrelated third account received private message in initial state');
    // Server-side anti-spam limit: a single account cannot flood one direct conversation.
    const burstConv=[uid,uidC].sort().join('_');
    let burstOk=0,burstLimited=0;
    for(let i=0;i<16;i++){
      const br=await post('w',{u:uid,t:token,op:'set',c:'msgs',id:'dm_burst_'+i,v:{c:burstConv,from:uid,t:Date.now(),kind:'e2e',body:fakeE2EBody(),e:2,rx:{},rd:0}});
      if(br.status===200)burstOk++;else if(br.status===429)burstLimited++;else assert.fail('unexpected DM burst status '+br.status);
    }
    assert.equal(burstOk,15,'conversation message rate limit did not allow the expected initial burst');
    assert.equal(burstLimited,1,'conversation message rate limit did not block the excess message');
    console.log('PASS: P-256 key validation, strict JSON content type, CSRF Origin checks, baseline headers, request-target limits, profile allowlist and image-signature validation');
    console.log('PASS: cross-account isolation, ciphertext integrity, DM privacy/block enforcement, plaintext-DM rejection, gift rate limiting, strict message schema, group-role invariants and removed-member write revocation');
    console.log('PASS: unrelated third account cannot read private conversation state');
    // A stream ticket issued moments before logout must not open a new authenticated SSE stream.
    const ticketBeforeLogout=await post('session/streamticket',{u:uid,t:token});assert.equal(ticketBeforeLogout.status,200,'pre-logout stream ticket issuance failed');
    r=await post('auth/revoke',{u:uid,t:token});assert.equal(r.status,200,'session revocation failed');
    const revokedStream=await fetch(base+'stream?ticket='+encodeURIComponent(ticketBeforeLogout.body.ticket));assert.equal(revokedStream.status,401,'stream ticket remained usable after logout');
    r=await post('w',{u:uid,t:token,op:'update',c:'users',id:uid,v:{bio:'should fail'}});assert.equal(r.status,401,'revoked token remained valid');
    const media=await fetch(base+'doc/media/not-a-real-file');assert.equal(media.status,401,'media endpoint allowed anonymous access');
    // Account deletion must also remove uploaded media from disk and ownership index.
    const token2='c'.repeat(32);
    r=await post('auth/register',{token:token2,name:'MediaTest',un:'media_test',pk:validPk,seen:Date.now(),salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'c'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});
    assert.equal(r.status,200,'second registration failed');const uid2=r.body.uid;
    const changePw=await post('rec/set',{u:uid2,t:token2,salt:Buffer.from('new-salt-1234567').toString('base64'),proof:'f'.repeat(64),old:'c'.repeat(64),vault:'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='});
    assert.equal(changePw.status,200,'password change failed with correct current proof');assert.match(changePw.body.token,/^[a-f0-9]{64}$/,'password change did not return rotated session token');
    r=await post('w',{u:uid2,t:token2,op:'update',c:'users',id:uid2,v:{bio:'old token must fail'}});assert.equal(r.status,401,'old session token survived password change');
    r=await post('w',{u:uid2,t:changePw.body.token,op:'update',c:'users',id:uid2,v:{bio:'new token works'}});assert.equal(r.status,200,'rotated session token was not accepted');
    const mediaId='test_media_01';
    // A MIME label must match the actual image signature; arbitrary bytes must be rejected.
    r=await post('w',{u:uid2,t:changePw.body.token,op:'set',c:'media',id:'fake_media_01',v:{d:'data:image/png;base64,aGVsbG8='}});assert.equal(r.status,400,'non-image bytes were accepted as PNG');
    const tinyPng='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/XioAAAAASUVORK5CYII=';
    r=await post('w',{u:uid2,t:changePw.body.token,op:'set',c:'media',id:mediaId,v:{d:tinyPng}});assert.equal(r.status,200,'valid PNG upload failed');
    assert(fs.existsSync(path.join(data,'media',mediaId)),'uploaded media was not saved');
    // Concurrent duplicate uploads must not overwrite the same ID or double-count quota.
    const raceId='race_media_01';
    const race=await Promise.all([post('w',{u:uid2,t:changePw.body.token,op:'set',c:'media',id:raceId,v:{d:tinyPng}}),post('w',{u:uid2,t:changePw.body.token,op:'set',c:'media',id:raceId,v:{d:tinyPng}})]);
    assert.equal(race.filter(x=>x.status===200).length,1,'concurrent duplicate media uploads both succeeded');
    assert.equal(race.filter(x=>x.status===409).length,1,'duplicate media upload was not rejected');
    const queryTokenMedia=await fetch(base+'doc/media/'+mediaId+'?u='+encodeURIComponent(uid2)+'&t='+encodeURIComponent(changePw.body.token));
    assert.equal(queryTokenMedia.status,401,'media endpoint still accepted session token in URL');
    const headerTokenMedia=await fetch(base+'doc/media/'+mediaId+'?u='+encodeURIComponent(uid2),{headers:{authorization:'Bearer '+changePw.body.token}});
    assert.equal(headerTokenMedia.status,200,'media endpoint rejected Authorization bearer token');
    const mediaPayload=await headerTokenMedia.json();assert.equal(mediaPayload.d,tinyPng,'authorized media response content mismatch');
    // Deleting an account must also purge conversations from groups it owned.
    const ownedGroup='owned_group_delete_test',ownedGroupMsg='owned_group_message_delete_test';
    r=await post('w',{u:uid2,t:changePw.body.token,op:'set',c:'groups',id:ownedGroup,v:{by:uid2,un:'owned_group_delete_test',mem:[uid2,uidB],adm:[uid2],ch:0}});assert.equal(r.status,200,'owned group setup failed');
    r=await post('w',{u:uidB,t:tokenB,op:'set',c:'msgs',id:ownedGroupMsg,v:{c:ownedGroup,from:uidB,t:Date.now(),kind:'text',body:'must be purged with group owner',rx:{},rd:0}});assert.equal(r.status,200,'owned group message setup failed');
    const deniedDelete=await post('account/delete',{u:uid2,t:changePw.body.token,proof:'a'.repeat(64)});
    assert.equal(deniedDelete.status,403,'account deletion accepted an incorrect cloud password');
    assert(fs.existsSync(path.join(data,'media',mediaId)),'failed reauthentication unexpectedly deleted account media');
    const confirmedDelete=await post('account/delete',{u:uid2,t:changePw.body.token,proof:'f'.repeat(64)});
    assert.equal(confirmedDelete.status,200,'account deletion failed after correct cloud-password proof');
    assert(!fs.existsSync(path.join(data,'media',mediaId)),'account deletion left media on disk');
    assert(!fs.existsSync(path.join(data,'media','race_media_01')),'account deletion left concurrent-upload media on disk');
    await wait(750);
    const savedDb=JSON.parse(fs.readFileSync(path.join(data,'db.json'),'utf8'));
    assert(!savedDb.groups[ownedGroup],'account deletion left an owned group in the database');
    assert(!savedDb.msgs[ownedGroupMsg],'account deletion left messages in its deleted group');
    assert(!savedDb.users[uid2]&&!savedDb.rec[uid2]&&!savedDb.tokenMeta[uid2],'account deletion left account credentials or recovery data');
    console.log('PASS: recovery-start hides account existence; malformed oversized recovery IDs are bounded and rejected');
    console.log('PASS: cloud-password change rotates session token and invalidates old token');
    console.log('PASS: no implicit account bootstrap');
    console.log('PASS: server-assigned IDs, duplicate username rejection, atomic account/recovery registration');
    console.log('PASS: one-use stream tickets, replay rejection, active-session binding and logout invalidation');
    console.log('PASS: logout token revocation');
    console.log('PASS: media endpoint requires authentication, validates image signatures, rejects concurrent duplicate uploads, and forbids tokens in media URLs');
    console.log('PASS: account deletion removes owned media, group conversations, account credentials and recovery data');
    // Recovery must not install a token shorter than the authentication layer accepts.
    const tokenD='f'.repeat(64);
    const rd=await post('auth/register',{token:tokenD,name:'RecoveryTokenTest',un:'recovery_token_test',pk:validPk,salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsb25hc2R1dnd4eXo='});
    assert.equal(rd.status,200,'recovery-token test account registration failed');
    const shortRecovery=await post('rec/do',{uid:rd.body.uid,tok:'shorttoken1234567',proof:'a'.repeat(64)});
    assert.equal(shortRecovery.status,403,'recovery accepted a token too short for normal authentication');
    const stillValid=await post('w',{u:rd.body.uid,t:tokenD,op:'update',c:'users',id:rd.body.uid,v:{bio:'original session remains valid'}});
    assert.equal(stillValid.status,200,'invalid short-token recovery unexpectedly changed the session');
    console.log('PASS: recovery rejects tokens shorter than the normal authentication contract');
  }finally{
    child.kill('SIGTERM');
    await Promise.race([new Promise(r=>child.once('exit',r)),wait(1500)]);
    fs.rmSync(data,{recursive:true,force:true});
  }
}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});
